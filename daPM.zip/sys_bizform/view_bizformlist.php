﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <HEAD>
  <TITLE>业务表单预览页</TITLE>
	<link rel="stylesheet" href="/css/base.css">
 
	<style type="text/css">
		.header {height:30px; line-height:30px; padding:0px 15px; font-weight:bold; border-bottom:1px solid #ccc; background:#f0f0f0;}		
		.righttitle {height:30px; line-height:30px; padding:0px 5px;border-bottom:1px solid #f0f0f0;}
		
		.tableform>tbody>tr>td{padding:3px; vertical-align:top;}
		
	</style>
 </HEAD>
<BODY>
<div>
	<div class="righttitle">业务表单信息列表
	<a style="margin-left:320px;" href="javascript:void(0)" onclick="addpowertype();" >新建</a> | 
	<a href="javascript:void(0)" >删除</a> | 
	</div>
	
	<div id="pad_main">
	
	</div>

</div>
</BODY>
</HTML>


<script type="text/javascript" src="/plugin/da/daLoader_source_1.1.js"></script>
<script type="text/javascript" src="js/view_businessformlist.js"></script>

